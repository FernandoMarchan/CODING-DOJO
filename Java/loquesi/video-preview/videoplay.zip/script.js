let video=document.getElementById ("primervideo")

function over(element) {
video.play()
}
    
function out(element) {
    video.pause()
    
}